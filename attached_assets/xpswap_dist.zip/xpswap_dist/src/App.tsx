import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { WalletProvider } from './contexts/WalletContext';
import WalletButton from './components/common/WalletButton';
import SwapCard from './components/swap/SwapCard';
import { ROUTES } from './constants';

// 임시 페이지 컴포넌트
const HomePage = () => (
  <div className="max-w-4xl p-8 mx-auto">
    <h1 className="mb-6 text-3xl font-bold text-center">XpSwap - Xphere 블록체인 기반 DEX</h1>
    <p className="mb-8 text-center text-gray-600">
      XpSwap은 Xphere 블록체인 상에서 운영되는 탈중앙화 거래소(DEX)로, 토큰 스왑, 유동성 공급 등의 기능을 제공합니다.
    </p>
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
      <div className="p-6 bg-white rounded-lg shadow-md">
        <h2 className="mb-4 text-xl font-semibold">토큰 스왑</h2>
        <p className="mb-4 text-gray-600">다양한 Xphere 기반 토큰을 즉시 교환하세요.</p>
        <Link
          to={ROUTES.swap}
          className="inline-block px-4 py-2 text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
        >
          스왑하기
        </Link>
      </div>
      <div className="p-6 bg-white rounded-lg shadow-md">
        <h2 className="mb-4 text-xl font-semibold">유동성 풀</h2>
        <p className="mb-4 text-gray-600">유동성을 제공하고 수수료 수익을 얻으세요.</p>
        <Link
          to={ROUTES.pool}
          className="inline-block px-4 py-2 text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
        >
          풀 보기
        </Link>
      </div>
      <div className="p-6 bg-white rounded-lg shadow-md">
        <h2 className="mb-4 text-xl font-semibold">대시보드</h2>
        <p className="mb-4 text-gray-600">자산 및 수익을 한눈에 확인하세요.</p>
        <Link
          to={ROUTES.dashboard}
          className="inline-block px-4 py-2 text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
        >
          대시보드
        </Link>
      </div>
    </div>
  </div>
);

const PoolPage = () => (
  <div className="max-w-4xl p-8 mx-auto">
    <h1 className="mb-6 text-2xl font-bold">유동성 풀</h1>
    <p className="mb-4 text-gray-600">이 기능은 개발 중입니다.</p>
    <Link to={ROUTES.home} className="text-indigo-600 hover:underline">
      홈으로 돌아가기
    </Link>
  </div>
);

const DashboardPage = () => (
  <div className="max-w-4xl p-8 mx-auto">
    <h1 className="mb-6 text-2xl font-bold">대시보드</h1>
    <p className="mb-4 text-gray-600">이 기능은 개발 중입니다.</p>
    <Link to={ROUTES.home} className="text-indigo-600 hover:underline">
      홈으로 돌아가기
    </Link>
  </div>
);

const SwapPage = () => (
  <div className="max-w-4xl p-8 mx-auto">
    <h1 className="mb-6 text-2xl font-bold">토큰 스왑</h1>
    <SwapCard />
  </div>
);

const NotFoundPage = () => (
  <div className="max-w-4xl p-8 mx-auto text-center">
    <h1 className="mb-6 text-2xl font-bold">404 - 페이지를 찾을 수 없습니다</h1>
    <Link to={ROUTES.home} className="text-indigo-600 hover:underline">
      홈으로 돌아가기
    </Link>
  </div>
);

function App() {
  return (
    <WalletProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          {/* 네비게이션 바 */}
          <nav className="bg-white shadow-sm">
            <div className="max-w-7xl px-4 mx-auto sm:px-6 lg:px-8">
              <div className="flex justify-between h-16">
                <div className="flex">
                  <div className="flex items-center flex-shrink-0">
                    <Link to={ROUTES.home} className="text-xl font-bold text-indigo-600">
                      XpSwap
                    </Link>
                  </div>
                  <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                    <Link
                      to={ROUTES.swap}
                      className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900 border-b-2 border-transparent hover:border-gray-300"
                    >
                      스왑
                    </Link>
                    <Link
                      to={ROUTES.pool}
                      className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900 border-b-2 border-transparent hover:border-gray-300"
                    >
                      풀
                    </Link>
                    <Link
                      to={ROUTES.dashboard}
                      className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-900 border-b-2 border-transparent hover:border-gray-300"
                    >
                      대시보드
                    </Link>
                  </div>
                </div>
                <div className="flex items-center">
                  <WalletButton />
                </div>
              </div>
            </div>
          </nav>

          {/* 메인 콘텐츠 */}
          <main>
            <Routes>
              <Route path={ROUTES.home} element={<HomePage />} />
              <Route path={ROUTES.swap} element={<SwapPage />} />
              <Route path={ROUTES.pool} element={<PoolPage />} />
              <Route path={ROUTES.dashboard} element={<DashboardPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>

          {/* 푸터 */}
          <footer className="py-4 mt-12 text-center text-gray-500 bg-white border-t">
            <div className="max-w-7xl px-4 mx-auto sm:px-6 lg:px-8">
              <p>© 2025 XpSwap. All rights reserved.</p>
            </div>
          </footer>
        </div>
      </Router>
    </WalletProvider>
  );
}

export default App;
