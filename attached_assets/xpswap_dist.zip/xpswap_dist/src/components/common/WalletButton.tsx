import React from 'react';
import { useWallet } from '../../contexts/WalletContext';

interface WalletButtonProps {
  className?: string;
}

const WalletButton: React.FC<WalletButtonProps> = ({ className }) => {
  const { walletState, connectWallet, disconnectWallet, isConnecting } = useWallet();

  // 지갑 주소 포맷팅 (앞 6자리 + ... + 뒤 4자리)
  const formatAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  return (
    <button
      onClick={walletState.connected ? disconnectWallet : connectWallet}
      disabled={isConnecting}
      className={`px-4 py-2 font-medium rounded-lg transition-colors ${
        walletState.connected
          ? 'bg-green-100 text-green-800 hover:bg-green-200'
          : 'bg-indigo-600 text-white hover:bg-indigo-700'
      } ${isConnecting ? 'opacity-70 cursor-not-allowed' : ''} ${className}`}
    >
      {isConnecting
        ? '연결 중...'
        : walletState.connected
        ? formatAddress(walletState.address || '')
        : '지갑 연결'}
    </button>
  );
};

export default WalletButton;
