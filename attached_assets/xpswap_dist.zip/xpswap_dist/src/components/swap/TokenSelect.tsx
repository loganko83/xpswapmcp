import React, { useState, useEffect } from 'react';
import { useWallet } from '../../contexts/WalletContext';
import { DEFAULT_TOKENS } from '../../constants';

// 토큰 타입 정의
interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  logoURI: string;
}

interface TokenSelectProps {
  onSelect: (token: Token) => void;
  selectedToken?: Token;
  otherToken?: Token; // 다른 입력/출력에서 선택된 토큰 (중복 선택 방지)
}

const TokenSelect: React.FC<TokenSelectProps> = ({ onSelect, selectedToken, otherToken }) => {
  const { walletState } = useWallet();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [tokens, setTokens] = useState<Token[]>(DEFAULT_TOKENS);
  const [filteredTokens, setFilteredTokens] = useState<Token[]>(tokens);

  // 검색어에 따라 토큰 필터링
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredTokens(tokens);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = tokens.filter(
        token =>
          token.symbol.toLowerCase().includes(query) ||
          token.name.toLowerCase().includes(query) ||
          token.address.toLowerCase().includes(query)
      );
      setFilteredTokens(filtered);
    }
  }, [searchQuery, tokens]);

  // 토큰 선택 핸들러
  const handleSelectToken = (token: Token) => {
    onSelect(token);
    setIsOpen(false);
    setSearchQuery('');
  };

  // 모달 토글
  const toggleModal = () => {
    setIsOpen(!isOpen);
    setSearchQuery('');
  };

  return (
    <div className="relative">
      {/* 토큰 선택 버튼 */}
      <button
        type="button"
        className="flex items-center justify-between w-full px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        onClick={toggleModal}
      >
        {selectedToken ? (
          <div className="flex items-center">
            <img
              src={selectedToken.logoURI}
              alt={selectedToken.symbol}
              className="w-6 h-6 mr-2 rounded-full"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/images/tokens/default.png';
              }}
            />
            <span>{selectedToken.symbol}</span>
          </div>
        ) : (
          <span>토큰 선택</span>
        )}
        <svg
          className="w-5 h-5 ml-2 -mr-1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path
            fillRule="evenodd"
            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
            clipRule="evenodd"
          />
        </svg>
      </button>

      {/* 토큰 선택 모달 */}
      {isOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* 배경 오버레이 */}
            <div
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              aria-hidden="true"
              onClick={toggleModal}
            ></div>

            {/* 모달 패널 */}
            <div className="inline-block overflow-hidden text-left align-bottom transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="px-4 pt-5 pb-4 bg-white sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="w-full mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg font-medium leading-6 text-gray-900" id="modal-title">
                      토큰 선택
                    </h3>
                    <div className="mt-2">
                      {/* 검색 입력 */}
                      <input
                        type="text"
                        className="block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        placeholder="이름, 심볼 또는 주소로 검색"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />

                      {/* 토큰 목록 */}
                      <div className="mt-4 overflow-y-auto max-h-60">
                        {filteredTokens.length > 0 ? (
                          filteredTokens.map((token) => (
                            <button
                              key={token.address}
                              className={`flex items-center w-full px-4 py-2 text-sm text-left hover:bg-gray-100 ${
                                otherToken && otherToken.address === token.address
                                  ? 'opacity-50 cursor-not-allowed'
                                  : 'cursor-pointer'
                              }`}
                              onClick={() => {
                                if (!otherToken || otherToken.address !== token.address) {
                                  handleSelectToken(token);
                                }
                              }}
                              disabled={otherToken && otherToken.address === token.address}
                            >
                              <img
                                src={token.logoURI}
                                alt={token.symbol}
                                className="w-8 h-8 mr-3 rounded-full"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = '/assets/images/tokens/default.png';
                                }}
                              />
                              <div>
                                <div className="font-medium">{token.symbol}</div>
                                <div className="text-xs text-gray-500">{token.name}</div>
                              </div>
                            </button>
                          ))
                        ) : (
                          <div className="px-4 py-2 text-sm text-center text-gray-500">
                            검색 결과가 없습니다
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="px-4 py-3 bg-gray-50 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="inline-flex justify-center w-full px-4 py-2 text-base font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={toggleModal}
                >
                  닫기
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TokenSelect;
