import React, { useState, useEffect } from 'react';
import { useWallet } from '../../contexts/WalletContext';
import TokenSelect from './TokenSelect';
import swapService from '../../services/swap';
import { ethers } from 'ethers';
import { CONTRACT_ADDRESSES } from '../../constants';

// 토큰 타입 정의
interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  logoURI: string;
}

const SwapCard: React.FC = () => {
  const { walletState } = useWallet();
  const [fromToken, setFromToken] = useState<Token | undefined>(undefined);
  const [toToken, setToToken] = useState<Token | undefined>(undefined);
  const [fromAmount, setFromAmount] = useState<string>('');
  const [toAmount, setToAmount] = useState<string>('');
  const [slippage, setSlippage] = useState<string>('0.5');
  const [isSwapping, setIsSwapping] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // 금액 입력 변경 시 견적 업데이트
  useEffect(() => {
    const updateToAmount = async () => {
      if (
        fromToken &&
        toToken &&
        fromAmount &&
        parseFloat(fromAmount) > 0 &&
        walletState.provider
      ) {
        try {
          setError(null);
          const path = [fromToken.address, toToken.address];
          const amounts = await swapService.getAmountsOut(
            fromAmount,
            path,
            walletState.provider
          );
          
          if (amounts && amounts.length > 1) {
            setToAmount(amounts[1]);
          }
        } catch (error: any) {
          console.error('견적 조회 오류:', error);
          setError('견적을 가져올 수 없습니다. 다시 시도해주세요.');
          setToAmount('');
        }
      } else {
        setToAmount('');
      }
    };

    updateToAmount();
  }, [fromToken, toToken, fromAmount, walletState.provider]);

  // 토큰 위치 변경
  const handleSwitchTokens = () => {
    setFromToken(toToken);
    setToToken(fromToken);
    setFromAmount(toAmount);
    setToAmount(fromAmount);
  };

  // 스왑 실행
  const handleSwap = async () => {
    if (
      !walletState.connected ||
      !walletState.signer ||
      !fromToken ||
      !toToken ||
      !fromAmount ||
      !toAmount
    ) {
      setError('지갑이 연결되지 않았거나 입력이 유효하지 않습니다.');
      return;
    }

    try {
      setIsSwapping(true);
      setError(null);

      // 슬리피지 계산
      const slippagePercent = parseFloat(slippage) / 100;
      const amountOutMin = (
        parseFloat(toAmount) * (1 - slippagePercent)
      ).toString();

      // 현재 시간 + 20분 (트랜잭션 유효 기간)
      const deadline = Math.floor(Date.now() / 1000) + 20 * 60;

      // 스왑 경로
      const path = [fromToken.address, toToken.address];

      // 네이티브 토큰(XP)인지 확인
      const isFromNative = fromToken.address === '0x0000000000000000000000000000000000000000';
      const isToNative = toToken.address === '0x0000000000000000000000000000000000000000';

      let tx;

      if (isFromNative) {
        // XP -> 토큰 스왑
        tx = await swapService.swapExactXPForTokens(
          fromAmount,
          amountOutMin,
          path,
          walletState.address!,
          deadline,
          walletState.signer
        );
      } else if (isToNative) {
        // 토큰 -> XP 스왑
        tx = await swapService.swapExactTokensForXP(
          fromAmount,
          amountOutMin,
          path,
          walletState.address!,
          deadline,
          walletState.signer
        );
      } else {
        // 토큰 -> 토큰 스왑
        // 먼저 라우터 컨트랙트에 대한 토큰 승인 필요
        const approveTx = await swapService.approveToken(
          fromToken.address,
          CONTRACT_ADDRESSES.router,
          fromAmount,
          walletState.signer
        );
        
        // 승인 트랜잭션 완료 대기
        await approveTx.wait();
        
        // 스왑 실행
        tx = await swapService.swapExactTokensForTokens(
          fromAmount,
          amountOutMin,
          path,
          walletState.address!,
          deadline,
          walletState.signer
        );
      }

      // 트랜잭션 완료 대기
      await tx.wait();
      
      // 스왑 완료 후 입력 초기화
      setFromAmount('');
      setToAmount('');
      
      // 성공 메시지 또는 알림 표시 (실제 구현에서는 토스트 알림 등 사용)
      alert('스왑이 성공적으로 완료되었습니다!');
      
    } catch (error: any) {
      console.error('스왑 오류:', error);
      setError(error.message || '스왑 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setIsSwapping(false);
    }
  };

  return (
    <div className="w-full max-w-md p-4 mx-auto bg-white rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">토큰 스왑</h2>
        <button
          onClick={() => setIsSettingsOpen(!isSettingsOpen)}
          className="p-2 text-gray-500 rounded-full hover:bg-gray-100"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-5 h-5"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      </div>

      {/* 설정 패널 */}
      {isSettingsOpen && (
        <div className="p-3 mb-4 bg-gray-100 rounded-md">
          <h3 className="mb-2 text-sm font-medium">슬리피지 허용 오차</h3>
          <div className="flex space-x-2">
            {['0.1', '0.5', '1.0'].map((value) => (
              <button
                key={value}
                className={`px-3 py-1 text-sm rounded-md ${
                  slippage === value
                    ? 'bg-indigo-600 text-white'
                    : 'bg-white text-gray-700'
                }`}
                onClick={() => setSlippage(value)}
              >
                {value}%
              </button>
            ))}
            <div className="relative flex-1">
              <input
                type="text"
                className="w-full px-3 py-1 text-sm border border-gray-300 rounded-md"
                placeholder="사용자 정의"
                value={slippage}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^\d*\.?\d*$/.test(value)) {
                    setSlippage(value);
                  }
                }}
              />
              <span className="absolute inset-y-0 right-0 flex items-center pr-2 text-sm text-gray-500">
                %
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 입력 토큰 */}
      <div className="p-4 mb-2 border border-gray-200 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-500">보내는 금액</span>
          {walletState.connected && fromToken && (
            <span className="text-xs text-gray-500">
              잔액: {walletState.balance || '0'} {fromToken.symbol}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            className="flex-1 p-2 text-lg bg-transparent focus:outline-none"
            placeholder="0.0"
            value={fromAmount}
            onChange={(e) => {
              const value = e.target.value;
              if (/^\d*\.?\d*$/.test(value)) {
                setFromAmount(value);
              }
            }}
          />
          <TokenSelect
            onSelect={setFromToken}
            selectedToken={fromToken}
            otherToken={toToken}
          />
        </div>
      </div>

      {/* 토큰 전환 버튼 */}
      <div className="flex justify-center -my-2">
        <button
          onClick={handleSwitchTokens}
          className="p-1 bg-white border border-gray-200 rounded-full"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-6 h-6 text-gray-500"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"
            />
          </svg>
        </button>
      </div>

      {/* 출력 토큰 */}
      <div className="p-4 mb-4 border border-gray-200 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-500">받는 금액</span>
          {walletState.connected && toToken && (
            <span className="text-xs text-gray-500">
              잔액: {/* 여기에 toToken 잔액 표시 */} {toToken.symbol}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            className="flex-1 p-2 text-lg bg-transparent focus:outline-none"
            placeholder="0.0"
            value={toAmount}
            readOnly
          />
          <TokenSelect
            onSelect={setToToken}
            selectedToken={toToken}
            otherToken={fromToken}
          />
        </div>
      </div>

      {/* 가격 정보 */}
      {fromToken && toToken && fromAmount && toAmount && parseFloat(fromAmount) > 0 && (
        <div className="p-3 mb-4 text-sm bg-gray-50 rounded-md">
          <div className="flex justify-between">
            <span className="text-gray-500">가격</span>
            <span>
              1 {fromToken.symbol} = {(parseFloat(toAmount) / parseFloat(fromAmount)).toFixed(6)}{' '}
              {toToken.symbol}
            </span>
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-gray-500">슬리피지 허용 오차</span>
            <span>{slippage}%</span>
          </div>
        </div>
      )}

      {/* 오류 메시지 */}
      {error && (
        <div className="p-3 mb-4 text-sm text-red-700 bg-red-100 rounded-md">
          {error}
        </div>
      )}

      {/* 스왑 버튼 */}
      <button
        onClick={handleSwap}
        disabled={
          !walletState.connected ||
          !fromToken ||
          !toToken ||
          !fromAmount ||
          !toAmount ||
          parseFloat(fromAmount) <= 0 ||
          isSwapping
        }
        className={`w-full py-3 text-white rounded-lg ${
          !walletState.connected ||
          !fromToken ||
          !toToken ||
          !fromAmount ||
          !toAmount ||
          parseFloat(fromAmount) <= 0 ||
          isSwapping
            ? 'bg-indigo-300 cursor-not-allowed'
            : 'bg-indigo-600 hover:bg-indigo-700'
        }`}
      >
        {!walletState.connected
          ? '지갑 연결 필요'
          : !fromToken || !toToken
          ? '토큰 선택'
          : !fromAmount || parseFloat(fromAmount) <= 0
          ? '금액 입력'
          : isSwapping
          ? '스왑 진행 중...'
          : '스왑'}
      </button>
    </div>
  );
};

export default SwapCard;
