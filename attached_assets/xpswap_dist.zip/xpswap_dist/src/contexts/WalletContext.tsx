import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import walletService, { WalletState } from '../services/wallet';

// 지갑 컨텍스트 타입 정의
interface WalletContextType {
  walletState: WalletState;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => Promise<void>;
  refreshBalance: () => Promise<void>;
  isConnecting: boolean;
}

// 기본 지갑 상태
const defaultWalletState: WalletState = {
  connected: false,
  address: null,
  chainId: null,
  provider: null,
  signer: null,
  balance: null,
  error: null,
};

// 지갑 컨텍스트 생성
const WalletContext = createContext<WalletContextType>({
  walletState: defaultWalletState,
  connectWallet: async () => {},
  disconnectWallet: async () => {},
  refreshBalance: async () => {},
  isConnecting: false,
});

// 지갑 컨텍스트 프로바이더 컴포넌트
export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [walletState, setWalletState] = useState<WalletState>(defaultWalletState);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);

  // 지갑 연결 함수
  const connectWallet = async () => {
    try {
      setIsConnecting(true);
      const state = await walletService.connectWallet();
      setWalletState(state);
    } catch (error) {
      console.error('지갑 연결 오류:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  // 지갑 연결 해제 함수
  const disconnectWallet = async () => {
    try {
      const state = await walletService.disconnectWallet();
      setWalletState(state);
    } catch (error) {
      console.error('지갑 연결 해제 오류:', error);
    }
  };

  // 잔액 새로고침 함수
  const refreshBalance = async () => {
    if (walletState.connected && walletState.address && walletState.provider) {
      try {
        const balance = await walletService.getBalance(walletState.address, walletState.provider);
        setWalletState((prev) => ({ ...prev, balance }));
      } catch (error) {
        console.error('잔액 새로고침 오류:', error);
      }
    }
  };

  // 이더리움 이벤트 리스너 설정
  useEffect(() => {
    if (window.ethereum) {
      // 계정 변경 이벤트
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          // 사용자가 계정 연결 해제
          disconnectWallet();
        } else if (walletState.connected) {
          // 계정 변경됨, 상태 업데이트
          connectWallet();
        }
      };

      // 체인 변경 이벤트
      const handleChainChanged = () => {
        // 체인이 변경되면 페이지 새로고침 (권장 방법)
        window.location.reload();
      };

      // 이벤트 리스너 등록
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      // 컴포넌트 언마운트 시 이벤트 리스너 제거
      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, [walletState.connected]);

  return (
    <WalletContext.Provider
      value={{
        walletState,
        connectWallet,
        disconnectWallet,
        refreshBalance,
        isConnecting,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

// 지갑 컨텍스트 사용을 위한 커스텀 훅
export const useWallet = () => useContext(WalletContext);

export default WalletContext;
