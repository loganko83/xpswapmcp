// Xphere 블록체인 네트워크 정보
export const XPHERE_NETWORK = {
  name: 'XPHERE 2.0',
  chainId: 20250217,
  rpcUrl: 'https://en-bkk.x-phere.com',
  currencySymbol: 'XP',
  blockExplorerUrl: 'https://xp.tamsa.io/main'
};

// 기본 토큰 목록
export const DEFAULT_TOKENS = [
  {
    address: '0x0000000000000000000000000000000000000000', // 네이티브 토큰 주소
    symbol: 'XP',
    name: 'Xphere',
    decimals: 18,
    logoURI: '/assets/images/tokens/xp.png'
  }
  // 추가 토큰은 여기에 추가
];

// 컨트랙트 주소 (실제 배포 후 업데이트 필요)
export const CONTRACT_ADDRESSES = {
  factory: '0x0000000000000000000000000000000000000000', // 예시 주소, 실제 배포 후 업데이트 필요
  router: '0x0000000000000000000000000000000000000000',  // 예시 주소, 실제 배포 후 업데이트 필요
  staking: '0x0000000000000000000000000000000000000000'  // 예시 주소, 실제 배포 후 업데이트 필요
};

// 앱 라우트
export const ROUTES = {
  home: '/',
  swap: '/swap',
  pool: '/pool',
  addLiquidity: '/pool/add',
  removeLiquidity: '/pool/remove',
  stake: '/stake',
  dashboard: '/dashboard'
};
