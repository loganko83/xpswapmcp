import { ethers } from 'ethers';
import { XPHERE_NETWORK } from '../constants';

// 지갑 연결 상태 타입
export type WalletState = {
  connected: boolean;
  address: string | null;
  chainId: number | null;
  provider: ethers.providers.Web3Provider | null;
  signer: ethers.Signer | null;
  balance: string | null;
  error: string | null;
};

// 지갑 서비스 클래스
class WalletService {
  // ZIGAP 지갑 연결 (WalletConnect 사용)
  async connectWallet(): Promise<WalletState> {
    try {
      // 브라우저에 이더리움 공급자가 있는지 확인 (ZIGAP 또는 다른 지갑)
      if (window.ethereum) {
        // 이더리움 공급자로 Web3Provider 생성
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        
        // 사용자에게 지갑 연결 요청
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        // 사이너 가져오기
        const signer = provider.getSigner();
        const address = await signer.getAddress();
        
        // 현재 체인 ID 가져오기
        const { chainId } = await provider.getNetwork();
        
        // 잔액 가져오기
        const balanceWei = await provider.getBalance(address);
        const balance = ethers.utils.formatEther(balanceWei);
        
        // Xphere 네트워크 확인
        if (chainId !== XPHERE_NETWORK.chainId) {
          // 네트워크 전환 요청
          try {
            await window.ethereum.request({
              method: 'wallet_switchEthereumChain',
              params: [{ chainId: `0x${XPHERE_NETWORK.chainId.toString(16)}` }],
            });
          } catch (switchError: any) {
            // 네트워크가 지갑에 추가되지 않은 경우, 추가 요청
            if (switchError.code === 4902) {
              await window.ethereum.request({
                method: 'wallet_addEthereumChain',
                params: [
                  {
                    chainId: `0x${XPHERE_NETWORK.chainId.toString(16)}`,
                    chainName: XPHERE_NETWORK.name,
                    nativeCurrency: {
                      name: XPHERE_NETWORK.currencySymbol,
                      symbol: XPHERE_NETWORK.currencySymbol,
                      decimals: 18,
                    },
                    rpcUrls: [XPHERE_NETWORK.rpcUrl],
                    blockExplorerUrls: [XPHERE_NETWORK.blockExplorerUrl],
                  },
                ],
              });
            } else {
              throw switchError;
            }
          }
          
          // 네트워크 전환 후 체인 ID 다시 가져오기
          const { chainId: updatedChainId } = await provider.getNetwork();
          
          return {
            connected: true,
            address,
            chainId: updatedChainId,
            provider,
            signer,
            balance,
            error: null,
          };
        }
        
        return {
          connected: true,
          address,
          chainId,
          provider,
          signer,
          balance,
          error: null,
        };
      } else {
        // 이더리움 공급자가 없는 경우 (ZIGAP 앱이 설치되지 않음)
        return {
          connected: false,
          address: null,
          chainId: null,
          provider: null,
          signer: null,
          balance: null,
          error: 'ZIGAP 앱이 설치되지 않았거나 브라우저에서 접근할 수 없습니다. ZIGAP 앱을 설치하고 다시 시도해주세요.',
        };
      }
    } catch (error: any) {
      console.error('지갑 연결 오류:', error);
      return {
        connected: false,
        address: null,
        chainId: null,
        provider: null,
        signer: null,
        balance: null,
        error: error.message || '지갑 연결 중 오류가 발생했습니다.',
      };
    }
  }

  // 지갑 연결 해제
  async disconnectWallet(): Promise<WalletState> {
    return {
      connected: false,
      address: null,
      chainId: null,
      provider: null,
      signer: null,
      balance: null,
      error: null,
    };
  }

  // 잔액 가져오기
  async getBalance(address: string, provider: ethers.providers.Web3Provider): Promise<string> {
    try {
      const balanceWei = await provider.getBalance(address);
      return ethers.utils.formatEther(balanceWei);
    } catch (error: any) {
      console.error('잔액 조회 오류:', error);
      throw new Error(error.message || '잔액 조회 중 오류가 발생했습니다.');
    }
  }

  // 트랜잭션 전송
  async sendTransaction(
    transaction: ethers.providers.TransactionRequest,
    signer: ethers.Signer
  ): Promise<ethers.providers.TransactionResponse> {
    try {
      return await signer.sendTransaction(transaction);
    } catch (error: any) {
      console.error('트랜잭션 전송 오류:', error);
      throw new Error(error.message || '트랜잭션 전송 중 오류가 발생했습니다.');
    }
  }
}

export default new WalletService();
