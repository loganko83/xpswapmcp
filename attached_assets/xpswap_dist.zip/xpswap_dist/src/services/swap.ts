import { ethers } from 'ethers';
import { CONTRACT_ADDRESSES } from '../constants';

// 스왑 서비스 클래스
class SwapService {
  // 토큰 스왑 실행
  async swapExactTokensForTokens(
    amountIn: string,
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number,
    signer: ethers.Signer
  ): Promise<ethers.providers.TransactionResponse> {
    try {
      // 라우터 컨트랙트 ABI (실제 ABI로 대체 필요)
      const routerAbi = [
        'function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)'
      ];
      
      // 라우터 컨트랙트 인스턴스 생성
      const routerContract = new ethers.Contract(
        CONTRACT_ADDRESSES.router,
        routerAbi,
        signer
      );
      
      // 스왑 트랜잭션 실행
      return await routerContract.swapExactTokensForTokens(
        ethers.utils.parseUnits(amountIn, 18), // 토큰 소수점에 맞게 조정 필요
        ethers.utils.parseUnits(amountOutMin, 18), // 토큰 소수점에 맞게 조정 필요
        path,
        to,
        deadline
      );
    } catch (error: any) {
      console.error('토큰 스왑 오류:', error);
      throw new Error(error.message || '토큰 스왑 중 오류가 발생했습니다.');
    }
  }

  // 네이티브 토큰(XP)을 다른 토큰으로 스왑
  async swapExactXPForTokens(
    amountIn: string,
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number,
    signer: ethers.Signer
  ): Promise<ethers.providers.TransactionResponse> {
    try {
      // 라우터 컨트랙트 ABI (실제 ABI로 대체 필요)
      const routerAbi = [
        'function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) external payable returns (uint[] memory amounts)'
      ];
      
      // 라우터 컨트랙트 인스턴스 생성
      const routerContract = new ethers.Contract(
        CONTRACT_ADDRESSES.router,
        routerAbi,
        signer
      );
      
      // 스왑 트랜잭션 실행
      return await routerContract.swapExactETHForTokens(
        ethers.utils.parseUnits(amountOutMin, 18), // 토큰 소수점에 맞게 조정 필요
        path,
        to,
        deadline,
        { value: ethers.utils.parseEther(amountIn) }
      );
    } catch (error: any) {
      console.error('XP 스왑 오류:', error);
      throw new Error(error.message || 'XP 스왑 중 오류가 발생했습니다.');
    }
  }

  // 토큰을 네이티브 토큰(XP)으로 스왑
  async swapExactTokensForXP(
    amountIn: string,
    amountOutMin: string,
    path: string[],
    to: string,
    deadline: number,
    signer: ethers.Signer
  ): Promise<ethers.providers.TransactionResponse> {
    try {
      // 라우터 컨트랙트 ABI (실제 ABI로 대체 필요)
      const routerAbi = [
        'function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) external returns (uint[] memory amounts)'
      ];
      
      // 라우터 컨트랙트 인스턴스 생성
      const routerContract = new ethers.Contract(
        CONTRACT_ADDRESSES.router,
        routerAbi,
        signer
      );
      
      // 스왑 트랜잭션 실행
      return await routerContract.swapExactTokensForETH(
        ethers.utils.parseUnits(amountIn, 18), // 토큰 소수점에 맞게 조정 필요
        ethers.utils.parseUnits(amountOutMin, 18), // 토큰 소수점에 맞게 조정 필요
        path,
        to,
        deadline
      );
    } catch (error: any) {
      console.error('토큰을 XP로 스왑 오류:', error);
      throw new Error(error.message || '토큰을 XP로 스왑 중 오류가 발생했습니다.');
    }
  }

  // 토큰 승인 (allowance)
  async approveToken(
    tokenAddress: string,
    spenderAddress: string,
    amount: string,
    signer: ethers.Signer
  ): Promise<ethers.providers.TransactionResponse> {
    try {
      // ERC20 토큰 ABI
      const erc20Abi = [
        'function approve(address spender, uint256 amount) external returns (bool)'
      ];
      
      // 토큰 컨트랙트 인스턴스 생성
      const tokenContract = new ethers.Contract(
        tokenAddress,
        erc20Abi,
        signer
      );
      
      // 승인 트랜잭션 실행
      return await tokenContract.approve(
        spenderAddress,
        ethers.constants.MaxUint256 // 무제한 승인 (또는 특정 금액으로 제한 가능)
      );
    } catch (error: any) {
      console.error('토큰 승인 오류:', error);
      throw new Error(error.message || '토큰 승인 중 오류가 발생했습니다.');
    }
  }

  // 토큰 잔액 조회
  async getTokenBalance(
    tokenAddress: string,
    ownerAddress: string,
    provider: ethers.providers.Provider
  ): Promise<string> {
    try {
      // ERC20 토큰 ABI
      const erc20Abi = [
        'function balanceOf(address owner) external view returns (uint256)'
      ];
      
      // 토큰 컨트랙트 인스턴스 생성
      const tokenContract = new ethers.Contract(
        tokenAddress,
        erc20Abi,
        provider
      );
      
      // 잔액 조회
      const balance = await tokenContract.balanceOf(ownerAddress);
      return ethers.utils.formatUnits(balance, 18); // 토큰 소수점에 맞게 조정 필요
    } catch (error: any) {
      console.error('토큰 잔액 조회 오류:', error);
      throw new Error(error.message || '토큰 잔액 조회 중 오류가 발생했습니다.');
    }
  }

  // 스왑 가격 견적 조회
  async getAmountsOut(
    amountIn: string,
    path: string[],
    provider: ethers.providers.Provider
  ): Promise<string[]> {
    try {
      // 라우터 컨트랙트 ABI (실제 ABI로 대체 필요)
      const routerAbi = [
        'function getAmountsOut(uint amountIn, address[] memory path) public view returns (uint[] memory amounts)'
      ];
      
      // 라우터 컨트랙트 인스턴스 생성
      const routerContract = new ethers.Contract(
        CONTRACT_ADDRESSES.router,
        routerAbi,
        provider
      );
      
      // 가격 견적 조회
      const amounts = await routerContract.getAmountsOut(
        ethers.utils.parseUnits(amountIn, 18), // 토큰 소수점에 맞게 조정 필요
        path
      );
      
      // 결과를 문자열 배열로 변환
      return amounts.map((amount: ethers.BigNumber) => 
        ethers.utils.formatUnits(amount, 18) // 토큰 소수점에 맞게 조정 필요
      );
    } catch (error: any) {
      console.error('가격 견적 조회 오류:', error);
      throw new Error(error.message || '가격 견적 조회 중 오류가 발생했습니다.');
    }
  }
}

export default new SwapService();
