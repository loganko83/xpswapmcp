# XpSwap - Xphere 블록체인 기반 탈중앙화 거래소

XpSwap은 Xphere 블록체인 상에서 운영되는 탈중앙화 거래소(DEX)로, KlaySwap과 유사한 사용자 경험 및 기능 세트를 제공합니다. 이 프로젝트는 Replit에서 개발 및 배포할 수 있도록 설계되었습니다.

## 프로젝트 개요

- **블록체인**: Xphere 2.0
- **지갑 통합**: ZIGAP 앱
- **주요 기능**: 토큰 스왑, 유동성 풀 (향후 확장 가능)

## Xphere 네트워크 정보

- **Network name**: XPHERE 2.0
- **Default RPC URL**: https://en-bkk.x-phere.com
- **Chain ID**: 20250217
- **Currency symbol**: XP
- **Block explorer URL**: https://xp.tamsa.io/main

## 설치 및 실행 방법

### Replit에서 실행하기

1. Replit에서 새 프로젝트 생성 (React 템플릿 선택)
2. 이 zip 파일의 내용을 Replit 프로젝트에 업로드
3. 터미널에서 다음 명령어 실행:

```bash
npm install
npm start
```

### 로컬 환경에서 실행하기

1. 프로젝트 폴더로 이동
2. 다음 명령어 실행:

```bash
npm install
npm start
```

## 주요 기능

### 지갑 연결
- ZIGAP 지갑 연결 지원 (WalletConnect 또는 이더리움 공급자 주입 방식)
- 계정 정보 및 잔액 표시
- 네트워크 전환 지원

### 토큰 스왑
- 토큰 선택 및 금액 입력
- 가격 영향 및 슬리피지 설정
- 스왑 실행 및 트랜잭션 확인

### 유동성 풀 (향후 구현 예정)
- 풀 목록 표시 (TVL, 거래량, APR)
- 유동성 추가/제거
- LP 토큰 관리

## 프로젝트 구조

```
xpswap/
├── public/                     # 정적 파일
├── src/                        # 소스 코드
│   ├── components/             # 재사용 가능한 UI 컴포넌트
│   │   ├── common/             # 공통 컴포넌트
│   │   ├── swap/               # 스왑 관련 컴포넌트
│   │   ├── pool/               # 풀 관련 컴포넌트
│   │   └── dashboard/          # 대시보드 관련 컴포넌트
│   ├── contexts/               # 컨텍스트
│   ├── constants/              # 상수
│   ├── hooks/                  # 커스텀 훅
│   ├── services/               # 서비스
│   ├── utils/                  # 유틸리티 함수
│   ├── styles/                 # 스타일
│   └── abis/                   # 컨트랙트 ABI
├── package.json                # 패키지 정보 및 의존성
└── tailwind.config.js          # Tailwind CSS 설정
```

## 기술 스택

- **프론트엔드**: React.js, TypeScript
- **스타일링**: Tailwind CSS
- **블록체인 통신**: ethers.js, Web3.js
- **라우팅**: React Router
- **상태 관리**: React Context API

## 스마트 컨트랙트 참조

XpSwap의 프론트엔드는 다음 스마트 컨트랙트와 상호작용합니다:

1. **XpSwapFactory**: 토큰 페어 생성 및 관리
2. **XpSwapRouter**: 스왑 로직 및 유동성 관리
3. **XpSwapPair**: 특정 토큰 페어의 유동성 풀

## 향후 개발 계획

1. 유동성 풀 기능 완전 구현
2. 스테이킹 및 거버넌스 기능 추가
3. 대시보드 및 분석 기능 강화
4. V3 집중 유동성 기능 구현

## 참고 사항

- 초기 개발은 V2 스타일 AMM에 집중 (Uniswap V2/KlaySwap V2 참조)
- 실제 스마트 컨트랙트 배포 후 컨트랙트 주소 업데이트 필요
- 사용자 경험을 최우선으로 고려하여 개발
